#ifndef _DEQUE_H
#define _DEQUE_H

#include <iostream>
using namespace std;

template <class T>
class Deque
{
	//请填写程序
};

//请填写程序

#endif
